# DragonflyJS
DragonflyJS is a tiny vanilla JavaScript library that enables drag and drop functionality with zero dependencies. By implementing this library, a user is able to drag and drop elements and reorder them. https://getbutterfly.com/dragonflyjs-vanilla-javascript-drag-and-drop/

Current version: `1.2.0`

## Changelog

= 1.2.0 =
* Add callback event

= 1.1.0 =
* First release
